# Yasmin AI (Android)
Gemini-powered assistant: chat, app launch, YouTube/music, screen control, coding helper, game agent.

## Build (Termux)
```bash
pkg install -y openjdk-17 gradle aapt2 wget unzip
# install Android SDK (platform 34, build-tools 34.0.0), export ANDROID_SDK_ROOT
# uncomment the aapt2 line in gradle.properties
gradle wrapper --gradle-version 8.4   # once
./gradlew assembleDebug
```
APK: `app/build/outputs/apk/debug/app-debug.apk`

## Use
Menu → Settings (Gemini key) → Enable Screen Control (Accessibility) → chat.
Game agent uses screenshots (Android 11+). Use only in single-player/allowed games.
