package com.yasmin.ai.automation

import android.accessibilityservice.AccessibilityService
import android.content.Context
import com.yasmin.ai.service.GameAgentService
import com.yasmin.ai.service.YasminAccessibilityService
import org.json.JSONObject

class ActionExecutor(private val ctx: Context) {

    private val needControl = "Screen Control is off — enable it from the menu first."

    suspend fun execute(a: JSONObject): String {
        val svc = YasminAccessibilityService.instance
        return when (val type = a.optString("type")) {
            "open_app" -> {
                val n = a.optString("name")
                if (AppLauncher.launch(ctx, n)) "Opened $n" else "Couldn't find an app called \"$n\""
            }
            "play_media" -> MediaController.play(ctx, a.optString("query"), a.optString("platform", "youtube"))
            "back" -> svc?.let { if (it.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)) "Went back" else "Failed" } ?: needControl
            "home" -> svc?.let { if (it.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME)) "Home" else "Failed" } ?: needControl
            "recents" -> svc?.let { if (it.performGlobalAction(AccessibilityService.GLOBAL_ACTION_RECENTS)) "Recents" else "Failed" } ?: needControl
            "click_text" -> svc?.let { if (it.clickText(a.optString("text"))) "Tapped \"${a.optString("text")}\"" else "Couldn't find \"${a.optString("text")}\" on screen" } ?: needControl
            "type_text" -> svc?.let { if (it.typeText(a.optString("text"))) "Typed" else "No focused text field" } ?: needControl
            "read_screen" -> svc?.readScreen() ?: needControl
            "tap", "swipe" -> {
                if (svc == null) needControl else {
                    GameAutomation(svc).runOne(JSONObject(a.toString()).put("a", type))
                    "Done"
                }
            }
            "game_agent" -> {
                if (svc == null) needControl else {
                    GameAgentService.start(ctx, a.optString("game", "game"), a.optString("goal", "play"))
                    "Game agent started — switch to the game (3s)"
                }
            }
            "stop_game" -> { GameAgentService.stop(ctx); "Game agent stopped" }
            else -> "Unknown action: $type"
        }
    }
}
