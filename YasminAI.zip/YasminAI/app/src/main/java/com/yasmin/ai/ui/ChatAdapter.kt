package com.yasmin.ai.ui

import android.graphics.Color
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.yasmin.ai.R

class ChatAdapter(private val items: List<ChatMessage>) : RecyclerView.Adapter<ChatAdapter.VH>() {

    class VH(v: View) : RecyclerView.ViewHolder(v) { val t: TextView = v.findViewById(R.id.msg) }

    override fun onCreateViewHolder(p: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_chat, p, false))

    override fun onBindViewHolder(h: VH, i: Int) {
        val m = items[i]
        h.t.text = m.text
        h.t.setBackgroundResource(if (m.isUser) R.drawable.bubble_user else R.drawable.bubble_bot)
        h.t.setTextColor(if (m.isUser) Color.WHITE else Color.BLACK)
        val lp = h.t.layoutParams as FrameLayout.LayoutParams
        lp.gravity = if (m.isUser) Gravity.END else Gravity.START
        h.t.layoutParams = lp
    }

    override fun getItemCount() = items.size
}
