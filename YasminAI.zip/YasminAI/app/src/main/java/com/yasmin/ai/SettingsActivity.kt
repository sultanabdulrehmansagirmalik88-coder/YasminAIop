package com.yasmin.ai

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.yasmin.ai.data.SecurePrefs

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_settings)
        title = "Settings"
        val prefs = SecurePrefs(this)
        val key = findViewById<EditText>(R.id.key)
        val model = findViewById<Spinner>(R.id.model)
        model.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, SecurePrefs.MODELS)
        model.setSelection(SecurePrefs.MODELS.indexOf(prefs.model).coerceAtLeast(0))
        key.setText(prefs.apiKey)
        findViewById<Button>(R.id.save).setOnClickListener {
            prefs.apiKey = key.text.toString()
            prefs.model = model.selectedItem as String
            Toast.makeText(this, "Saved 💕", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
