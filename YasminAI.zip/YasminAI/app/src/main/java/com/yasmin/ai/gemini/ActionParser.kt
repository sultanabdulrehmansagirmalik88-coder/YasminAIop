package com.yasmin.ai.gemini

import org.json.JSONObject

object ActionParser {
    data class Result(val text: String, val actions: List<JSONObject>)

    private val re = Regex("```action\\s*(\\{.*?\\})\\s*```", RegexOption.DOT_MATCHES_ALL)

    fun parse(reply: String): Result {
        val actions = re.findAll(reply)
            .mapNotNull { runCatching { JSONObject(it.groupValues[1]) }.getOrNull() }
            .toList()
        return Result(re.replace(reply, "").trim(), actions)
    }
}
