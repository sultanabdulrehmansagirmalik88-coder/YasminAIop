package com.yasmin.ai.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.yasmin.ai.automation.GameAutomation
import com.yasmin.ai.automation.GameBrain
import com.yasmin.ai.data.SecurePrefs
import com.yasmin.ai.data.YasminPersona
import com.yasmin.ai.gemini.GeminiApiClient
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableSharedFlow

class GameAgentService : Service() {

    companion object {
        val events = MutableSharedFlow<String>(extraBufferCapacity = 16)
        private const val MAX_ROUNDS = 80

        fun start(ctx: Context, game: String, goal: String) {
            ctx.startForegroundService(
                Intent(ctx, GameAgentService::class.java).putExtra("game", game).putExtra("goal", goal))
        }
        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, GameAgentService::class.java)) }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var job: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val game = intent?.getStringExtra("game").orEmpty()
        val goal = intent?.getStringExtra("goal").orEmpty()
        goForeground(game)
        job?.cancel()
        job = scope.launch { loop(game, goal) }
        return START_NOT_STICKY
    }

    private fun goForeground(game: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("agent", "Game agent", NotificationManager.IMPORTANCE_LOW))
        val n: Notification = NotificationCompat.Builder(this, "agent")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentTitle("Yasmin is playing $game")
            .setContentText("Open Yasmin and use the menu to stop")
            .setOngoing(true).build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
    }

    private suspend fun loop(game: String, goal: String) {
        try {
            val svc = YasminAccessibilityService.instance
            if (svc == null) { events.tryEmit("Screen Control is off."); return }
            val brain = GameBrain(GeminiApiClient(SecurePrefs(this), YasminPersona.GAME_BRAIN, keepHistory = false))
            val auto = GameAutomation(svc)
            delay(3000) // time to switch to the game
            for (round in 1..MAX_ROUNDS) {
                val shot = svc.screenshotB64()
                if (shot == null) { events.tryEmit("Screenshot failed (needs Android 11+)."); return }
                val plan = brain.plan(game, goal, shot)
                events.tryEmit("Round $round: ${plan.note}")
                if (plan.done) { events.tryEmit("Agent finished: ${plan.note}"); return }
                auto.run(plan.steps)
                delay(1200)
            }
            events.tryEmit("Agent stopped after $MAX_ROUNDS rounds.")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            events.tryEmit("Agent error: ${e.message}")
        } finally {
            stopSelf()
        }
    }

    override fun onDestroy() { scope.cancel(); super.onDestroy() }
}
