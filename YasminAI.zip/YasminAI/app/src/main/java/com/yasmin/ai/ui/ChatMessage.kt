package com.yasmin.ai.ui

data class ChatMessage(val text: String, val isUser: Boolean)
