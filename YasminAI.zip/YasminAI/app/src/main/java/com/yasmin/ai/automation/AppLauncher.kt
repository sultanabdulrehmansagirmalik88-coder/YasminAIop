package com.yasmin.ai.automation

import android.content.Context
import android.content.Intent

object AppLauncher {
    fun launch(ctx: Context, nameOrPkg: String): Boolean {
        val pm = ctx.packageManager
        val direct = pm.getLaunchIntentForPackage(nameOrPkg)
        val intent = direct ?: run {
            val q = nameOrPkg.trim().lowercase()
            val apps = pm.queryIntentActivities(
                Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == q }
                ?: apps.firstOrNull { it.loadLabel(pm).toString().lowercase().contains(q) }
            hit?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
        } ?: return false
        ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return true
    }
}
