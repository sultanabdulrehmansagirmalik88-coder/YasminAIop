package com.yasmin.ai.gemini

import com.yasmin.ai.data.SecurePrefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiApiClient(
    private val prefs: SecurePrefs,
    private val systemPrompt: String,
    private val keepHistory: Boolean = true
) {
    private val http = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build()
    private var history = JSONArray()

    fun clear() { history = JSONArray() }

    private fun content(role: String, text: String) = JSONObject()
        .put("role", role)
        .put("parts", JSONArray().put(JSONObject().put("text", text)))

    suspend fun send(text: String, imageB64: String? = null): String = withContext(Dispatchers.IO) {
        val key = prefs.apiKey
        check(key.isNotEmpty()) { "No API key yet — open Settings and paste your Gemini key." }

        val userParts = JSONArray().put(JSONObject().put("text", text))
        if (imageB64 != null) {
            userParts.put(JSONObject().put("inline_data",
                JSONObject().put("mime_type", "image/jpeg").put("data", imageB64)))
        }
        val contents = JSONArray()
        if (keepHistory) for (i in 0 until history.length()) contents.put(history.get(i))
        contents.put(JSONObject().put("role", "user").put("parts", userParts))

        val body = JSONObject()
            .put("system_instruction", JSONObject().put("parts",
                JSONArray().put(JSONObject().put("text", systemPrompt))))
            .put("contents", contents)

        val req = Request.Builder()
            .url("https://generativelanguage.googleapis.com/v1beta/models/${prefs.model}:generateContent")
            .header("x-goog-api-key", key)
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        http.newCall(req).execute().use { resp ->
            val raw = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) {
                val msg = runCatching { JSONObject(raw).getJSONObject("error").getString("message") }
                    .getOrDefault(raw.take(200))
                error("Gemini ${resp.code}: $msg")
            }
            val parts = JSONObject(raw).optJSONArray("candidates")?.optJSONObject(0)
                ?.optJSONObject("content")?.optJSONArray("parts")
            val sb = StringBuilder()
            if (parts != null) for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
            val reply = sb.toString().ifBlank { "(no response)" }

            if (keepHistory) {
                history.put(content("user", text)).put(content("model", reply))
                while (history.length() > 24) history.remove(0)
            }
            reply
        }
    }
}
