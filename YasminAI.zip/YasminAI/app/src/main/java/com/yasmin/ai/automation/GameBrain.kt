package com.yasmin.ai.automation

import com.yasmin.ai.gemini.GeminiApiClient
import org.json.JSONArray
import org.json.JSONObject

class GameBrain(private val client: GeminiApiClient) {
    data class Plan(val done: Boolean, val note: String, val steps: JSONArray)

    private val log = ArrayDeque<String>()

    suspend fun plan(game: String, goal: String, screenshotB64: String): Plan {
        val prompt = "Game: $game\nGoal: $goal\nRecent notes: ${log.joinToString(" | ")}\nPick the next steps."
        val raw = client.send(prompt, screenshotB64)
        val json = runCatching {
            JSONObject(raw.substring(raw.indexOf('{'), raw.lastIndexOf('}') + 1))
        }.getOrNull() ?: return Plan(true, "Couldn't understand the model reply", JSONArray())
        val note = json.optString("note")
        log.addLast(note); if (log.size > 5) log.removeFirst()
        return Plan(json.optBoolean("done", false), note, json.optJSONArray("steps") ?: JSONArray())
    }
}
