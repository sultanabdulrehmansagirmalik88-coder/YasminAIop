package com.yasmin.ai

import android.content.ClipData
import android.content.ClipboardManager
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.yasmin.ai.data.SecurePrefs
import com.yasmin.ai.data.YasminPersona
import com.yasmin.ai.gemini.GeminiApiClient
import kotlinx.coroutines.launch

class CodingAssistantActivity : AppCompatActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_coding)
        title = "Coding Assistant"
        val client = GeminiApiClient(SecurePrefs(this), YasminPersona.CODING, keepHistory = false)
        val mode = findViewById<Spinner>(R.id.mode)
        val code = findViewById<EditText>(R.id.code)
        val out = findViewById<TextView>(R.id.out)
        mode.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Generate", "Debug", "Explain"))

        findViewById<Button>(R.id.run).setOnClickListener {
            val input = code.text.toString().trim()
            if (input.isEmpty()) return@setOnClickListener
            out.text = "Thinking…"
            lifecycleScope.launch {
                out.text = try { client.send("${mode.selectedItem}:\n$input") }
                catch (e: Exception) { "Error: ${e.message}" }
            }
        }
        findViewById<Button>(R.id.copy).setOnClickListener {
            (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager)
                .setPrimaryClip(ClipData.newPlainText("yasmin", out.text))
            Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
        }
    }
}
