package com.yasmin.ai.automation

import com.yasmin.ai.service.YasminAccessibilityService
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject

/** Runs touch steps. All coordinates are normalized 0-1000 (top-left origin). */
class GameAutomation(private val svc: YasminAccessibilityService) {

    suspend fun run(steps: JSONArray) {
        val dm = svc.resources.displayMetrics
        for (i in 0 until steps.length()) {
            val s = steps.optJSONObject(i) ?: continue
            fun x(k: String) = (s.optDouble(k, 500.0) / 1000.0 * dm.widthPixels).toFloat()
            fun y(k: String) = (s.optDouble(k, 500.0) / 1000.0 * dm.heightPixels).toFloat()
            when (s.optString("a")) {
                "tap" -> svc.tap(x("x"), y("y"))
                "hold" -> svc.tap(x("x"), y("y"), s.optLong("ms", 800).coerceIn(100, 5000))
                "swipe" -> svc.swipe(x("x1"), y("y1"), x("x2"), y("y2"), s.optLong("ms", 300).coerceIn(50, 3000))
                "wait" -> delay(s.optLong("ms", 500).coerceIn(0, 5000))
            }
            delay(150)
        }
    }

    suspend fun runOne(step: JSONObject) = run(JSONArray().put(step))
}
