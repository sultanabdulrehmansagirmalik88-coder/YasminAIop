package com.yasmin.ai

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.yasmin.ai.automation.ActionExecutor
import com.yasmin.ai.data.SecurePrefs
import com.yasmin.ai.data.YasminPersona
import com.yasmin.ai.gemini.ActionParser
import com.yasmin.ai.gemini.GeminiApiClient
import com.yasmin.ai.service.GameAgentService
import com.yasmin.ai.ui.ChatAdapter
import com.yasmin.ai.ui.ChatMessage
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
    private val msgs = mutableListOf<ChatMessage>()
    private lateinit var adapter: ChatAdapter
    private lateinit var client: GeminiApiClient
    private lateinit var executor: ActionExecutor
    private lateinit var rv: RecyclerView
    private lateinit var input: EditText
    private lateinit var status: TextView

    private val speech = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let {
            input.setText(it); send()
        }
    }
    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        client = GeminiApiClient(SecurePrefs(this), YasminPersona.CHAT)
        executor = ActionExecutor(applicationContext)
        rv = findViewById(R.id.rv); input = findViewById(R.id.input); status = findViewById(R.id.status)
        adapter = ChatAdapter(msgs)
        rv.layoutManager = LinearLayoutManager(this).apply { stackFromEnd = true }
        rv.adapter = adapter
        findViewById<Button>(R.id.send).setOnClickListener { send() }
        findViewById<Button>(R.id.mic).setOnClickListener { listen() }
        if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        lifecycleScope.launch { GameAgentService.events.collect { status.text = it } }
        add(ChatMessage("Hi love 💕 I'm Yasmin. Add your Gemini key in ⋮ → Settings, then tell me what to do.", false))
    }

    private fun add(m: ChatMessage) {
        msgs.add(m); adapter.notifyItemInserted(msgs.size - 1); rv.scrollToPosition(msgs.size - 1)
    }

    private fun listen() {
        try {
            speech.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "Speech recognition not available", Toast.LENGTH_SHORT).show()
        }
    }

    private fun send() {
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        input.setText("")
        add(ChatMessage(t, true))
        status.text = "Yasmin is typing…"
        lifecycleScope.launch {
            try {
                val r = ActionParser.parse(client.send(t))
                if (r.text.isNotEmpty()) add(ChatMessage(r.text, false))
                status.text = ""
                for (a in r.actions) {
                    val res = executor.execute(a)
                    if (a.optString("type") == "read_screen") add(ChatMessage(res, false)) else status.text = res
                }
            } catch (e: Exception) {
                add(ChatMessage("⚠️ ${e.message}", false)); status.text = ""
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean { menuInflater.inflate(R.menu.main_menu, menu); return true }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.m_settings -> startActivity(Intent(this, SettingsActivity::class.java))
            R.id.m_access -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            R.id.m_code -> startActivity(Intent(this, CodingAssistantActivity::class.java))
            R.id.m_stop -> { GameAgentService.stop(this); status.text = "Game agent stopped" }
            R.id.m_clear -> { msgs.clear(); adapter.notifyDataSetChanged(); client.clear() }
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }
}
